-- Run once on your MySQL database (my_platform).
-- Money received against an order. An order can have several (partial) payments.
CREATE TABLE IF NOT EXISTS order_payments (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  order_id     INT NOT NULL,
  amount       DECIMAL(12,2) NOT NULL,
  method       VARCHAR(30) NOT NULL DEFAULT 'cash',   -- cash, bank, jazzcash, easypaisa
  reference    VARCHAR(100) NULL,                     -- transaction id / receipt no.
  received_by  VARCHAR(100) NOT NULL,
  received_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_order (order_id),
  INDEX idx_received (received_at)
);

-- Salaries the admin pays to retailers and delivery boys. Rows are never edited or deleted.
CREATE TABLE IF NOT EXISTS salary_payments (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  staff_type    ENUM('retailer','delivery') NOT NULL,
  staff_id      INT NOT NULL,
  amount        DECIMAL(12,2) NOT NULL,
  salary_month  CHAR(7) NOT NULL,                     -- 'YYYY-MM'
  method        VARCHAR(30) NOT NULL DEFAULT 'cash',
  note          VARCHAR(255) NULL,
  paid_by       VARCHAR(100) NOT NULL,
  paid_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_staff (staff_type, staff_id, salary_month),
  INDEX idx_paid (paid_at)
);
