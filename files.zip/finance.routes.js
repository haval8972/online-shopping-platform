// Accounts & Finance API (admin only).
// Wire it in your Express app:
//   const financeRoutes = require('./finance.routes');
//   app.use('/api/finance', financeRoutes({ pool, requireAdmin }));
//
// ADAPT these to your real tables/columns (only place you need to change):
const T = {
  orders:     { table: 'orders',      id: 'id', total: 'total_amount', date: 'created_at' },
  items:      { table: 'order_items', orderId: 'order_id', name: 'product_name', qty: 'quantity', price: 'price' },
  retailer:   { table: 'retailers',   id: 'id', name: 'name' },
  delivery:   { table: 'delivery_boys', id: 'id', name: 'name' },
};

const express = require('express');
const METHODS = ['cash', 'bank', 'jazzcash', 'easypaisa'];

module.exports = function financeRoutes({ pool, requireAdmin }) {
  const r = express.Router();
  r.use(requireAdmin);

  const adminName = (req) => req.admin?.name || req.user?.name || 'admin';
  const money = (v) => Number(v);
  const validAmount = (v) => Number.isFinite(money(v)) && money(v) > 0 && money(v) < 10_000_000;

  // from/to as YYYY-MM-DD, default = current month
  function range(q) {
    const re = /^\d{4}-\d{2}-\d{2}$/;
    const now = new Date();
    const first = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
    const today = now.toISOString().slice(0, 10);
    return [re.test(q.from || '') ? q.from : first, re.test(q.to || '') ? q.to : today];
  }

  const ledgerSql = `
    SELECT o.${T.orders.id} AS id, o.${T.orders.total} AS total, o.${T.orders.date} AS date,
           COALESCE(SUM(p.amount), 0) AS collected
    FROM ${T.orders.table} o
    LEFT JOIN order_payments p ON p.order_id = o.${T.orders.id}
    WHERE o.${T.orders.date} >= ? AND o.${T.orders.date} < DATE_ADD(?, INTERVAL 1 DAY)
    GROUP BY o.${T.orders.id}, o.${T.orders.total}, o.${T.orders.date}`;

  r.get('/summary', async (req, res, next) => {
    try {
      const [from, to] = range(req.query);
      const [[s]] = await pool.query(
        `SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS billed, COALESCE(SUM(collected),0) AS collected
         FROM (${ledgerSql}) t`, [from, to]);
      const [[sal]] = await pool.query(
        `SELECT COALESCE(SUM(amount),0) AS paid FROM salary_payments
         WHERE paid_at >= ? AND paid_at < DATE_ADD(?, INTERVAL 1 DAY)`, [from, to]);
      res.json({
        from, to, orders: s.orders,
        billed: money(s.billed), collected: money(s.collected),
        pending: money(s.billed) - money(s.collected),
        salariesPaid: money(sal.paid),
        net: money(s.collected) - money(sal.paid),
      });
    } catch (e) { next(e); }
  });

  r.get('/orders', async (req, res, next) => {
    try {
      const [from, to] = range(req.query);
      const [rows] = await pool.query(`${ledgerSql} ORDER BY o.${T.orders.date} DESC LIMIT 500`, [from, to]);
      res.json(rows.map((o) => ({
        ...o, total: money(o.total), collected: money(o.collected),
        pending: money(o.total) - money(o.collected),
        status: money(o.collected) <= 0 ? 'unpaid' : money(o.collected) >= money(o.total) ? 'paid' : 'partial',
      })));
    } catch (e) { next(e); }
  });

  r.get('/products', async (req, res, next) => {
    try {
      const [from, to] = range(req.query);
      const [rows] = await pool.query(
        `SELECT i.${T.items.name} AS name, SUM(i.${T.items.qty}) AS sold,
                SUM(i.${T.items.qty} * i.${T.items.price}) AS revenue
         FROM ${T.items.table} i
         JOIN ${T.orders.table} o ON o.${T.orders.id} = i.${T.items.orderId}
         WHERE o.${T.orders.date} >= ? AND o.${T.orders.date} < DATE_ADD(?, INTERVAL 1 DAY)
         GROUP BY i.${T.items.name} ORDER BY revenue DESC LIMIT 100`, [from, to]);
      res.json(rows.map((p) => ({ name: p.name, sold: Number(p.sold), revenue: money(p.revenue) })));
    } catch (e) { next(e); }
  });

  // Record money received for an order
  r.post('/orders/:id/payments', async (req, res, next) => {
    const { amount, method = 'cash', reference = null } = req.body || {};
    const orderId = Number(req.params.id);
    if (!Number.isInteger(orderId) || !validAmount(amount) || !METHODS.includes(method))
      return res.status(400).json({ error: 'Check order, amount and payment method.' });
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const [[o]] = await conn.query(
        `SELECT ${T.orders.total} AS total FROM ${T.orders.table} WHERE ${T.orders.id} = ? FOR UPDATE`, [orderId]);
      if (!o) { await conn.rollback(); return res.status(404).json({ error: 'Order not found.' }); }
      const [[c]] = await conn.query('SELECT COALESCE(SUM(amount),0) AS got FROM order_payments WHERE order_id = ?', [orderId]);
      if (money(c.got) + money(amount) > money(o.total) + 0.001) {
        await conn.rollback();
        return res.status(400).json({ error: `Only ${money(o.total) - money(c.got)} is still due on this order.` });
      }
      await conn.query(
        'INSERT INTO order_payments (order_id, amount, method, reference, received_by) VALUES (?,?,?,?,?)',
        [orderId, money(amount), method, reference ? String(reference).slice(0, 100) : null, adminName(req)]);
      await conn.commit();
      res.status(201).json({ ok: true });
    } catch (e) { await conn.rollback(); next(e); } finally { conn.release(); }
  });

  // People who can be paid
  r.get('/staff', async (_req, res, next) => {
    try {
      const [ret] = await pool.query(`SELECT ${T.retailer.id} AS id, ${T.retailer.name} AS name FROM ${T.retailer.table} ORDER BY name`);
      const [del] = await pool.query(`SELECT ${T.delivery.id} AS id, ${T.delivery.name} AS name FROM ${T.delivery.table} ORDER BY name`);
      res.json({
        retailers: ret.map((x) => ({ ...x, type: 'retailer' })),
        delivery: del.map((x) => ({ ...x, type: 'delivery' })),
      });
    } catch (e) { next(e); }
  });

  r.get('/salaries', async (req, res, next) => {
    try {
      const month = /^\d{4}-\d{2}$/.test(req.query.month || '') ? req.query.month : null;
      const [rows] = await pool.query(
        `SELECT s.*, COALESCE(r.${T.retailer.name}, d.${T.delivery.name}) AS staff_name
         FROM salary_payments s
         LEFT JOIN ${T.retailer.table} r ON s.staff_type='retailer' AND r.${T.retailer.id}=s.staff_id
         LEFT JOIN ${T.delivery.table} d ON s.staff_type='delivery' AND d.${T.delivery.id}=s.staff_id
         ${month ? 'WHERE s.salary_month = ?' : ''}
         ORDER BY s.paid_at DESC LIMIT 500`, month ? [month] : []);
      res.json(rows.map((x) => ({ ...x, amount: money(x.amount) })));
    } catch (e) { next(e); }
  });

  r.post('/salaries', async (req, res, next) => {
    try {
      const { staff_type, staff_id, amount, salary_month, method = 'cash', note = null } = req.body || {};
      if (!['retailer', 'delivery'].includes(staff_type) || !Number.isInteger(Number(staff_id)) ||
          !validAmount(amount) || !/^\d{4}-(0[1-9]|1[0-2])$/.test(salary_month || '') || !METHODS.includes(method))
        return res.status(400).json({ error: 'Check person, amount, month and payment method.' });
      const t = T[staff_type];
      const [[who]] = await pool.query(`SELECT ${t.id} FROM ${t.table} WHERE ${t.id} = ?`, [Number(staff_id)]);
      if (!who) return res.status(404).json({ error: 'Person not found.' });
      await pool.query(
        `INSERT INTO salary_payments (staff_type, staff_id, amount, salary_month, method, note, paid_by)
         VALUES (?,?,?,?,?,?,?)`,
        [staff_type, Number(staff_id), money(amount), salary_month, method, note ? String(note).slice(0, 255) : null, adminName(req)]);
      res.status(201).json({ ok: true });
    } catch (e) { next(e); }
  });

  return r;
};
