'use client';
// Drop this into your admin dashboard, e.g. app/admin/finance/page.jsx
//   export { default } from '@/components/FinanceDashboard';
import { useCallback, useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL; // http://localhost:5000/api
// ADAPT: return whatever header your admin login already uses.
const authHeaders = () => {
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
  return token ? { Authorization: `Bearer ${token}` } : {};
};
async function api(path, opts = {}) {
  const res = await fetch(`${API}/finance${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    credentials: 'include',
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
const rs = (n) => 'Rs ' + Number(n || 0).toLocaleString('en-PK');
const METHODS = ['cash', 'bank', 'jazzcash', 'easypaisa'];
const monthNow = () => new Date().toISOString().slice(0, 7);
const dayStart = () => monthNow() + '-01';
const today = () => new Date().toISOString().slice(0, 10);

export default function FinanceDashboard() {
  const [tab, setTab] = useState('overview');
  const [from, setFrom] = useState(dayStart());
  const [to, setTo] = useState(today());
  const [summary, setSummary] = useState(null);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    setErr('');
    const q = `?from=${from}&to=${to}`;
    try {
      const [s, o, p] = await Promise.all([api('/summary' + q), api('/orders' + q), api('/products' + q)]);
      setSummary(s); setOrders(o); setProducts(p);
    } catch (e) { setErr(e.message); }
  }, [from, to]);
  useEffect(() => { load(); }, [load]);

  return (
    <div className="fin">
      <style>{css}</style>
      <header>
        <h1>Accounts and finance</h1>
        <div className="range">
          <input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
          <input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        </div>
      </header>
      {err && <p className="err" role="alert">{err}</p>}
      <nav>
        {[['overview', 'Overview'], ['orders', 'Orders'], ['products', 'Products sold'], ['salaries', 'Salaries']].map(([k, label]) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>
        ))}
      </nav>
      {tab === 'overview' && <Overview s={summary} />}
      {tab === 'orders' && <Orders rows={orders} reload={load} />}
      {tab === 'products' && <Products rows={products} />}
      {tab === 'salaries' && <Salaries reload={load} />}
    </div>
  );
}

function Overview({ s }) {
  if (!s) return <p className="muted">Loading figures…</p>;
  const items = [
    ['Billed', s.billed, `${s.orders} orders`],
    ['Collected', s.collected, 'payments received'],
    ['Still to collect', s.pending, 'unpaid balance'],
    ['Salaries paid', s.salariesPaid, 'retailers and delivery'],
    ['Net in hand', s.net, 'collected minus salaries'],
  ];
  return (
    <dl className="stats">
      {items.map(([k, v, note]) => (
        <div key={k} className={k === 'Net in hand' ? 'net' : ''}>
          <dt>{k}</dt><dd>{rs(v)}</dd><small>{note}</small>
        </div>
      ))}
    </dl>
  );
}

function Orders({ rows, reload }) {
  const [open, setOpen] = useState(null);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('cash');
  const [ref, setRef] = useState('');
  const [msg, setMsg] = useState('');

  async function save(o) {
    setMsg('');
    try {
      await api(`/orders/${o.id}/payments`, { method: 'POST', body: JSON.stringify({ amount, method, reference: ref }) });
      setOpen(null); setAmount(''); setRef(''); reload();
    } catch (e) { setMsg(e.message); }
  }
  if (!rows.length) return <p className="muted">No orders in this date range.</p>;
  return (
    <div className="scroll">
      <table>
        <thead><tr><th>Order</th><th>Date</th><th className="n">Total</th><th className="n">Collected</th><th className="n">Pending</th><th>Status</th><th /></tr></thead>
        <tbody>
          {rows.map((o) => (
            <>
              <tr key={o.id}>
                <td>#{o.id}</td><td>{new Date(o.date).toLocaleDateString('en-GB')}</td>
                <td className="n">{rs(o.total)}</td><td className="n">{rs(o.collected)}</td><td className="n">{rs(o.pending)}</td>
                <td><span className={`tag ${o.status}`}>{o.status}</span></td>
                <td>{o.pending > 0 && <button className="link" onClick={() => { setOpen(open === o.id ? null : o.id); setAmount(String(o.pending)); setMsg(''); }}>Record payment</button>}</td>
              </tr>
              {open === o.id && (
                <tr key={o.id + 'f'} className="form"><td colSpan={7}>
                  <input type="number" min="1" value={amount} onChange={(e) => setAmount(e.target.value)} aria-label="Amount" />
                  <select value={method} onChange={(e) => setMethod(e.target.value)}>{METHODS.map((m) => <option key={m}>{m}</option>)}</select>
                  <input placeholder="Receipt or transaction no." value={ref} onChange={(e) => setRef(e.target.value)} />
                  <button className="primary" onClick={() => save(o)}>Save payment</button>
                  {msg && <span className="err">{msg}</span>}
                </td></tr>
              )}
            </>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Products({ rows }) {
  if (!rows.length) return <p className="muted">No products sold in this date range.</p>;
  return (
    <div className="scroll"><table>
      <thead><tr><th>Product</th><th className="n">Units sold</th><th className="n">Revenue</th></tr></thead>
      <tbody>{rows.map((p) => <tr key={p.name}><td>{p.name}</td><td className="n">{p.sold}</td><td className="n">{rs(p.revenue)}</td></tr>)}</tbody>
    </table></div>
  );
}

function Salaries({ reload }) {
  const [staff, setStaff] = useState({ retailers: [], delivery: [] });
  const [history, setHistory] = useState([]);
  const [f, setF] = useState({ who: '', amount: '', month: monthNow(), method: 'cash', note: '' });
  const [msg, setMsg] = useState('');
  const [ok, setOk] = useState('');

  const refresh = useCallback(async () => {
    try { const [s, h] = await Promise.all([api('/staff'), api('/salaries')]); setStaff(s); setHistory(h); }
    catch (e) { setMsg(e.message); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);

  async function pay(e) {
    e.preventDefault(); setMsg(''); setOk('');
    const [staff_type, staff_id] = f.who.split(':');
    try {
      await api('/salaries', { method: 'POST', body: JSON.stringify({ staff_type, staff_id: Number(staff_id), amount: f.amount, salary_month: f.month, method: f.method, note: f.note }) });
      setOk('Salary recorded.'); setF({ ...f, amount: '', note: '' }); refresh(); reload();
    } catch (er) { setMsg(er.message); }
  }

  return (
    <>
      <form className="pay" onSubmit={pay}>
        <select required value={f.who} onChange={(e) => setF({ ...f, who: e.target.value })} aria-label="Person">
          <option value="">Choose person</option>
          <optgroup label="Retailers">{staff.retailers.map((x) => <option key={'r' + x.id} value={`retailer:${x.id}`}>{x.name}</option>)}</optgroup>
          <optgroup label="Delivery boys">{staff.delivery.map((x) => <option key={'d' + x.id} value={`delivery:${x.id}`}>{x.name}</option>)}</optgroup>
        </select>
        <input required type="number" min="1" placeholder="Amount (Rs)" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
        <input required type="month" value={f.month} onChange={(e) => setF({ ...f, month: e.target.value })} aria-label="Salary month" />
        <select value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}>{METHODS.map((m) => <option key={m}>{m}</option>)}</select>
        <input placeholder="Note (optional)" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} />
        <button className="primary">Pay salary</button>
        {msg && <span className="err">{msg}</span>}{ok && <span className="okmsg">{ok}</span>}
      </form>
      {!history.length ? <p className="muted">No salaries recorded yet.</p> : (
        <div className="scroll"><table>
          <thead><tr><th>Paid on</th><th>Name</th><th>Role</th><th>Month</th><th className="n">Amount</th><th>Method</th><th>Paid by</th></tr></thead>
          <tbody>{history.map((h) => (
            <tr key={h.id}><td>{new Date(h.paid_at).toLocaleDateString('en-GB')}</td><td>{h.staff_name}</td>
              <td>{h.staff_type === 'delivery' ? 'Delivery' : 'Retailer'}</td><td>{h.salary_month}</td>
              <td className="n">{rs(h.amount)}</td><td>{h.method}</td><td>{h.paid_by}</td></tr>
          ))}</tbody>
        </table></div>
      )}
    </>
  );
}

const css = `
.fin{--ink:#1b2a41;--paper:#f4f6f8;--line:#d5dbe1;--paid:#1f7a5a;--due:#b5651d;--accent:#1b2a41;
  font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ink);background:var(--paper);padding:20px;min-height:100vh}
.fin header{display:flex;flex-wrap:wrap;gap:12px;justify-content:space-between;align-items:center}
.fin h1{font-size:1.4rem;margin:0}
.fin input,.fin select{font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:6px;background:#fff;color:var(--ink)}
.fin .range{display:flex;gap:8px}
.fin nav{display:flex;gap:4px;margin:16px 0;border-bottom:1px solid var(--line);overflow-x:auto}
.fin nav button{font:inherit;background:none;border:0;padding:10px 14px;cursor:pointer;color:#5b6778;border-bottom:3px solid transparent}
.fin nav button.on{color:var(--ink);border-color:var(--ink);font-weight:600}
.fin button:focus-visible,.fin input:focus-visible,.fin select:focus-visible{outline:2px solid #2d6cdf;outline-offset:2px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:0;margin:0;border:1px solid var(--line);background:#fff}
.stats div{padding:16px 18px;border-right:1px solid var(--line)}
.stats dt{font-size:.85rem;color:#5b6778}.stats dd{margin:4px 0;font-size:1.5rem;font-weight:700}
.stats small{color:#7a8594}.stats .net{background:var(--ink);color:#fff}.stats .net dt,.stats .net small{color:#c5cedb}
.scroll{overflow-x:auto;background:#fff;border:1px solid var(--line)}
table{border-collapse:collapse;width:100%;min-width:640px}
th,td{padding:10px 12px;text-align:left;border-bottom:1px solid var(--line);white-space:nowrap}
th{font-size:.85rem;color:#5b6778;font-weight:600}.n{text-align:right}
.tag{padding:2px 8px;border-radius:99px;font-size:.8rem;border:1px solid}
.tag.paid{color:var(--paid);border-color:var(--paid)}.tag.unpaid{color:var(--due);border-color:var(--due)}.tag.partial{color:#7a5d00;border-color:#7a5d00}
.form td{background:#eef2f6;display:table-cell}.form input,.form select,.form button{margin-right:8px}
.pay{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:16px;padding:14px;background:#fff;border:1px solid var(--line)}
.primary{font:inherit;background:var(--ink);color:#fff;border:0;border-radius:6px;padding:9px 16px;cursor:pointer}
.link{font:inherit;background:none;border:0;color:#2d6cdf;cursor:pointer;text-decoration:underline}
.err{color:#b3261e}.okmsg{color:var(--paid)}.muted{color:#5b6778}
`;
