# Accounts & Finance module

1. Run `finance.sql` on your MySQL database.
2. Put `finance.routes.js` in your Express project and add:
   `app.use('/api/finance', require('./finance.routes')({ pool, requireAdmin }));`
   (`pool` = your mysql2/promise pool, `requireAdmin` = your existing admin-login middleware.)
3. Edit the `T` block at the top of `finance.routes.js` so the table/column names match yours.
4. Put `FinanceDashboard.jsx` in your Next.js app and add a link to it in the admin sidebar.
   Edit `authHeaders()` so it sends the same login token your other admin pages use.
